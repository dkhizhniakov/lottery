/**
 * Created by Dima Graebert on 2/20/2017.
 */
export const CONNECT = 'CONNECT';
export const DISCONNECT = 'DISCONNECT';
export const POST_MESSAGE = 'POST_MESSAGE';
export const GET_MESSAGE = 'GET_MESSAGE';
export const GET_ERROR = 'GET_ERROR';
