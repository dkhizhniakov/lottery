/**
 * Created by Dima Graebert on 2/20/2017.
 */
export const SUBSCRIBE = 'SUBSCRIBE';
export const UNSUBSCRIBE = 'UNSUBSCRIBE';
export const ADD_WINNER = 'ADD_WINNER';
